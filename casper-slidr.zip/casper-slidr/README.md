casper-slidr
============

Casper-Slidr is a theme for Ghost.js blogging platform. It is derived from the default Casper theme that comes as part of Ghost.js installation, hence the name...


THEME FEATURES
* Modified header for pages and posts
* Sliding menu for all pages and posts using jquery.mmenu
* Support for Disqus comments in posts
* Syntax highlighting for code using google-code-prettify
* Page view tracking using Google Analytics


HOW TO INSTALL THEME?
Copy casper-slidr.zip to <ghost install dir>/content/themes
wget https://github.com/baldeephira/casper-slidr
unzip casper-slidr.zip
Edit casper-slidr/default.hbs
** Set width/height for 'blog-logo' style, based on the your site logo
** Customize the list entries under 'my-menu' to your liking
** Remember to create ghost pages corresponding to these list entries
** Set your Google Analytics Account Number instead of UA-XXXXXXX-X
Edit casper-slidr/post.hbs
** Set disqus_shortname value to your site value instead of XXXXX
Copy your version of favicon to casper-slidr/assets/images/favicon.png


HOW TO BUILD FROM SOURCE?
Install git (brew install git)
Install node (brew install node)
Install grunt-cli (npm install -g grunt-cli)
git clone https://github.com/baldeephira/casper-slidr.git
cd casper-slidr
npm install
grunt